#ifndef MOD_AUTH_SSPI_H_TC_20020629
#define MOD_AUTH_SSPI_H_TC_20020629

/* Version information */
#define MOD_AUTH_SSPI_MODULE_NAME "mod_auth_sspi"

#define MOD_AUTH_SSPI_VERSION_MAJOR 1
#define MOD_AUTH_SSPI_VERSION_MID 0
#define MOD_AUTH_SSPI_VERSION_MINOR 3

/* Preprocessor macro definitions */
#define WIN32_LEAN_AND_MEAN 1
#define SECURITY_WIN32 1
#define WINNT_SECURITY_DLL "SECURITY.DLL"
#define WIN9X_SECURITY_DLL "SECUR32.DLL"
#define DEFAULT_SSPI_PACKAGE "NTLM"
#define UUID_STRING_LEN 64

#define _WIN32_WINNT 0x0400

/* System headers */
#include <windows.h>
#include <objbase.h>
#include <winsock2.h>
#include <sspi.h>
#include <security.h>

/* HTTPD headers */
#include "ap_config.h"
#include "apr_base64.h"
#include "httpd.h"
#include "http_config.h"
#include "http_core.h"
#include "http_log.h"
#include "http_protocol.h"
#include "http_request.h"
#include "apr_tables.h"
#include "apr_strings.h"

/* Type and struct definitions */
typedef struct sspi_module_struct {
    BOOL supportsSSPI;
    LPSTR defaultPackage;
    LPOSVERSIONINFO lpVersionInformation;
    char userDataKeyString[UUID_STRING_LEN];
    HMODULE securityDLL;
    SecurityFunctionTable *functable;
    ULONG numPackages;
    PSecPkgInfo pkgInfo;
#ifdef _DEBUG
    unsigned int currentlyDebugging;
#endif /* def _DEBUG */
} sspi_module_rec;

typedef struct sspi_connection_struct {
    apr_pool_t *pool;
    unsigned int have_credentials;

    /* Credentials */
    CredHandle client_credentials;
    CredHandle server_credentials;
    
    /* Client context */
    CtxtHandle client_context;
    TimeStamp client_ctxtexpiry;
    
    /* Server context */
    CtxtHandle server_context;
    TimeStamp server_ctxtexpiry;
    
    /* Information about the REMOTE_USER */
    HANDLE usertoken;
    char *username;
    apr_table_t *groups;
    char *package;
} sspi_connection_rec;

typedef struct sspi_config_struct {
    unsigned int sspi_on;
    unsigned int sspi_authoritative;
    unsigned int sspi_offersspi;
    unsigned int sspi_offerbasic;
    unsigned int sspi_omitdomain;
    unsigned int sspi_basicpreferred;
    unsigned int sspi_msie3hack;
    char *sspi_package;
    char *sspi_domain;
    char *sspi_usernamecase;
} sspi_config_rec;

typedef enum {
    typeSSPI = 1,
    typeBasic
} NTLMAuthType;

typedef struct sspi_header_struct {
  unsigned char *User;
  unsigned long UserLength;
  unsigned char *Domain;
  unsigned long DomainLength;
  unsigned char *Password;
  unsigned long PasswordLength;
  unsigned long Flags;
  NTLMAuthType authtype;
} sspi_header_rec;

/* Function Prototypes */
int authenticate_sspi_user(request_rec *);
int check_user_access(request_rec *);
apr_status_t cleanup_sspi_connection(void *);
void *create_sspi_dir_config(apr_pool_t *, char *);
sspi_config_rec *get_sspi_config_rec(request_rec *);
int get_sspi_header(request_rec *, sspi_header_rec *, sspi_config_rec *);
void note_sspi_auth_challenge(request_rec *, const char *, const char *);
void note_sspi_auth_failure(request_rec *);
char *uuencode_binary(apr_pool_t *, const unsigned char *, int);
char *uudecode_binary(apr_pool_t *, const unsigned char *, int *);

/* Global variables */
extern sspi_module_rec sspiModuleInfo;

#endif /* ndef MOD_AUTH_SSPI_H_TC_20020629 */
