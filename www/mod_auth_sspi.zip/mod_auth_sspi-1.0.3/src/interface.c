#include "mod_auth_sspi.h"

void *create_sspi_dir_config(apr_pool_t *p, char *d)
{
    sspi_config_rec *crec = (sspi_config_rec *) apr_pcalloc(p, sizeof(sspi_config_rec));

    /* Set the defaults. */
    crec->sspi_offersspi = TRUE;
    crec->sspi_authoritative = TRUE;

    return crec;
}

static int get_sspi_userpass(request_rec *r, sspi_config_rec *crec, 
                             sspi_header_rec *hdr, const char *auth_line)
{
    int len;

    /*
     * OK, we're here. The client is using SSPI and _should_ have 
     * sent a token to us. All we have to do is decode it and return...
     */
    if (auth_line) {
        hdr->Password = uudecode_binary(r->connection->pool, auth_line, &len);
        hdr->PasswordLength = len;
        hdr->authtype = typeSSPI;
    } else {
        if (crec->sspi_authoritative) {
            return HTTP_BAD_REQUEST;
        } else {
            return DECLINED;
        }
    }

    if (!hdr->PasswordLength || !hdr->Password) {
        if (crec->sspi_authoritative) {
            return HTTP_BAD_REQUEST;
        } else {
            return DECLINED;
        }
    }

    return OK;
}

static int get_basic_userpass(request_rec *r, sspi_config_rec *crec, 
                              sspi_header_rec *hdr, const char *auth_line)
{
    char *ptr, *domainptr;
    int len;

    if (!(ptr = uudecode_binary(r->connection->pool, auth_line, &len))) {
        note_sspi_auth_failure(r);
        if (crec->sspi_authoritative) {
            return HTTP_BAD_REQUEST;
        } else {
            return DECLINED;
        }
    }

    hdr->User = ap_getword_nulls(r->connection->pool, (const char**)&ptr, ':');
    if (hdr->User) {
        hdr->UserLength = strlen(hdr->User);
    } else {
        note_sspi_auth_failure(r);
        if (crec->sspi_authoritative) {
            return HTTP_BAD_REQUEST;
        } else {
            return DECLINED;
        }
    }

    for (domainptr = hdr->User; (unsigned long)(domainptr - hdr->User) < hdr->UserLength; domainptr++) {
        if (*domainptr == '\\') {
            *domainptr = '\0';
            hdr->Domain = hdr->User;
            hdr->DomainLength = strlen(hdr->Domain);
            hdr->User = domainptr + 1;
            hdr->UserLength = strlen(hdr->User);
            break;
        }
    }
    
    hdr->Password = ptr;
    if (hdr->Password) {
        hdr->PasswordLength = strlen(hdr->Password);
    } else {
        note_sspi_auth_failure(r);
        if (crec->sspi_authoritative) {
            return HTTP_BAD_REQUEST;
        } else {
            return DECLINED;
        }
    }

    hdr->authtype = typeBasic;

    return OK;
}

const char *get_authorization_header_name(request_rec *r)
{
    return (PROXYREQ_PROXY == r->proxyreq) ? "Proxy-Authorization"
        : "Authorization";
}

const char *get_authenticate_header_name(request_rec *r)
{
    return (PROXYREQ_PROXY == r->proxyreq) ? "Proxy-Authenticate"
        : "WWW-Authenticate";
}

int get_sspi_header(request_rec *r, sspi_header_rec *hdr, sspi_config_rec *crec)
{
    const char *scheme;
    const char *auth_line = apr_table_get(r->headers_in, 
        get_authorization_header_name(r));

    /*
     * If the client didn't supply an Authorization: (or Proxy-Authorization) 
     * header, we need to reply 401 and supply a WWW-Authenticate
     * (or Proxy-Authenticate) header indicating acceptable authentication
     * schemes. 
     */
    if (!auth_line) {
        note_sspi_auth_failure(r);
        return HTTP_UNAUTHORIZED;
    }

    /*
     * Do a quick check of the Authorization: header. If it is 'Basic', and we're
     * allowed, try a cleartext logon. Else if it isn't the selected package 
     * and we're authoritative, reply 401 again. 
     */
    scheme = ap_getword_white(r->pool, &auth_line);

    if (crec->sspi_offersspi && !lstrcmpi(scheme, crec->sspi_package)) {
        return get_sspi_userpass(r, crec, hdr, auth_line);
    } else if (crec->sspi_offerbasic && !lstrcmpi(scheme, "Basic")) {
        return get_basic_userpass(r, crec, hdr, auth_line);
    } else if (crec->sspi_authoritative) {
        ap_log_rerror(APLOG_MARK, APLOG_NOERRNO|APLOG_ERR, 0, r,
            "client used wrong authentication scheme: %s for %s (needed %s)", 
            scheme, r->uri, crec->sspi_package);
        note_sspi_auth_failure(r);
        return HTTP_UNAUTHORIZED;
    } else {
        return DECLINED;
    }

    return HTTP_INTERNAL_SERVER_ERROR;
}

void note_sspi_auth_failure(request_rec *r)
{
    const char *auth_hdr = get_authenticate_header_name(r);
    sspi_config_rec *crec = get_sspi_config_rec(r);

    char *hdr1 = NULL, *hdr2 = NULL, *basicline, *sspiline;

    basicline = apr_psprintf(r->pool, "Basic realm=\"%s\"", ap_auth_name(r));
    sspiline = apr_pstrdup(r->pool, crec->sspi_package);

    /* 
     * There are several options for configuring this feature. We can send
     * requests for either basic or NTLM auth or both. We can also order
     * them based on the server admin's preferences. 
     */

    /* TODO: new option for one www-authenticate header */

    if (crec->sspi_offersspi && crec->sspi_offerbasic) {
        if (crec->sspi_basicpreferred) {
            hdr1 = basicline;
            hdr2 = sspiline;
        } else {
            hdr1 = sspiline;
            hdr2 = basicline;
        }
    } else if (crec->sspi_offersspi) {
        hdr1 = sspiline;
    } else if (crec->sspi_offerbasic) {
        hdr1 = basicline;
    } else {
        /* 
         * don't offer anything? they must have explicitly turned offer_ntlm
         * off to get here! 
         */
    }
    
    if (hdr1) {
        apr_table_setn(r->err_headers_out, auth_hdr, hdr1);

        if (hdr2) {
            apr_table_addn(r->err_headers_out, auth_hdr, hdr2);
        }
    }
}

void note_sspi_auth_challenge(request_rec *r, const char *package, const char *challenge)
{
    sspi_config_rec *crec = get_sspi_config_rec(r);

    apr_table_setn(r->err_headers_out,
        (PROXYREQ_PROXY == r->proxyreq) ? "Proxy-Authenticate" : "WWW-Authenticate",
        apr_psprintf(r->pool, "%s %s", package, challenge));

    if (r->connection->keepalives)
        --r->connection->keepalives;

    /*
     * See above comment about ugly hack. 
     */
    if ((crec->sspi_msie3hack) && (r->proto_num < HTTP_VERSION(1,1))) {
        apr_table_setn(r->err_headers_out, 
        "Content-Length", apr_pstrdup(r->pool, "0"));
    }
}

char *uuencode_binary(apr_pool_t *p, const unsigned char *data, int len)
{
    int encodelength;
    char *encoded;

    encodelength = apr_base64_encode_len(len);
    encoded = apr_palloc(p, encodelength);

    if (encoded != NULL) {
        if (apr_base64_encode_binary(encoded, data, len) > 0) {
            return encoded;
        }
    }

    return NULL;
}

char *uudecode_binary(apr_pool_t *p, const unsigned char *data, int *decodelength)
{
    char *decoded;

    *decodelength = apr_base64_decode_len(data);
    decoded = apr_palloc(p, *decodelength);

    if (decoded != NULL) {
        *decodelength = apr_base64_decode_binary(decoded, data);
        if (*decodelength > 0) {
            decoded[(*decodelength)] = '\0';
            return decoded;
        }
    }

    return NULL;
}

