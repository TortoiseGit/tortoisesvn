#include "mod_auth_sspi.h"

static apr_table_t *groups_for_user(apr_pool_t *p, HANDLE usertoken)
{
    TOKEN_GROUPS *groupinfo = NULL;
    int groupinfosize = 0;
    SID_NAME_USE sidtype;
    char group_name[_MAX_PATH], domain_name[_MAX_PATH];
    int grouplen, domainlen;
    apr_table_t *grps;
    apr_pool_t *sp;
    unsigned int i;

    if ((GetTokenInformation(usertoken, TokenGroups, groupinfo, groupinfosize, &groupinfosize))
        || (GetLastError() != ERROR_INSUFFICIENT_BUFFER)) {
        return NULL;
    }

    apr_pool_create(&sp, p);
    groupinfo = apr_palloc(sp, groupinfosize);

    if (!GetTokenInformation(usertoken, TokenGroups, groupinfo, groupinfosize, &groupinfosize)) {
        return NULL;
    }

    grps = apr_table_make(p, groupinfo->GroupCount + 1);

    for (i = 0; i < groupinfo->GroupCount; i++) {
        grouplen = _MAX_PATH;
        domainlen = _MAX_PATH;

        if (!LookupAccountSid(NULL, groupinfo->Groups[i].Sid, 
                              group_name, &grouplen,
                              domain_name, &domainlen,
                              &sidtype)) {
            if (GetLastError() != ERROR_NONE_MAPPED) {
                return NULL;
            }
        } else {
            apr_table_setn(grps, apr_psprintf(p, "%s\\%s", domain_name, group_name), "in");
        }
    }

    apr_pool_destroy(sp);
    return grps;
}

int check_user_access(request_rec *r)
{
    sspi_config_rec *crec = get_sspi_config_rec(r);
    sspi_connection_rec *scr;
    char *user = r->user;
    int m = r->method_number;
    int method_restricted = 0;
    register int x;
    const char *t, *w;
    int needgroups = 0;
    const apr_array_header_t *reqs_arr = ap_requires(r);
    require_line *reqs;

    /*
     * If the switch isn't on, don't bother. 
     */
    if (!crec->sspi_on) {
        return DECLINED;
    }
    
    /* BUG FIX: tadc, 11-Nov-1995.  If there is no "requires" directive, 
     * then any user will do.
     */
    if (!reqs_arr) {
        return OK;
    }

    apr_pool_userdata_get((void**)&scr, sspiModuleInfo.userDataKeyString, r->connection->pool);
    reqs = (require_line *) reqs_arr->elts;

    /*
     * Did we authenticate this user?
     * If not, we don't want to do user/group checking.
     */
    if (scr->username != r->user) {
        return DECLINED;
    }
        
    /*
     * Fetching the groups for a user is a particularly expensive operation.
     * A quick scan of the requirements should tell us if we don't have to 
     * check groups. This results in a large performance increase for users
     * who only want to check names, or for a "valid-user".
     */
    for (x = 0; x < reqs_arr->nelts; x++) {
        if (!(reqs[x].method_mask & (1 << m))) {
            continue;
        }

        t = reqs[x].requirement;
        w = ap_getword_white(r->pool, &t);

        if (!lstrcmpi(w, "group")) {
            needgroups = 1;
            break;
        }
    }

    if (needgroups && scr->groups == NULL) {
        scr->groups = groups_for_user(r->connection->pool, scr->usertoken);
        if (scr->groups == NULL) {
            if (crec->sspi_authoritative) {
                ap_log_rerror(APLOG_MARK, APLOG_ERR, APR_FROM_OS_ERROR(GetLastError()), r,
                    "access to %s failed, reason: cannot get groups for user:"
                    "\"%s\"", r->uri, r->user);
                return HTTP_INTERNAL_SERVER_ERROR;
            } else {
                return DECLINED;
            }
        }
    }

    for (x = 0; x < reqs_arr->nelts; x++) {
        if (!(reqs[x].method_mask & (1 << m)))
            continue;

        method_restricted = 1;

        t = reqs[x].requirement;
        w = ap_getword_white(r->pool, &t);
        if (!lstrcmpi(w, "valid-user"))
            return OK;
        if (!lstrcmpi(w, "user")) {
            while (t[0]) {
            w = ap_getword_conf(r->pool, &t);
            if (!lstrcmpi(user, w))
                return OK;
            }
        }
        else if (!lstrcmpi(w, "group")) {
            while (t[0]) {
            w = ap_getword_conf(r->pool, &t);
            if (apr_table_get(scr->groups, w))
                return OK;
            }
        } else if (crec->sspi_authoritative) {
            /* if we aren't authoritative, any require directive could be
             * valid even if we don't grok it.  However, if we are 
             * authoritative, we can warn the user they did something wrong.
             * That something could be a missing "AuthAuthoritative off", but
             * more likely is a typo in the require directive.
             */
            ap_log_rerror(APLOG_MARK, APLOG_NOERRNO|APLOG_ERR, 0, r,
            "access to %s failed, reason: unknown require directive:"
            "\"%s\"", r->uri, reqs[x].requirement);
        }
    }

    if (!method_restricted) {
        return OK;
    }

    /* At this stage we know that the client isn't valid by our records. 
     * georg.weber@infineon.com: only free_credentials if it is_main */
    if (r->main == NULL) {
        cleanup_sspi_connection(scr);
    }

    if (!(crec->sspi_authoritative)) {
        return DECLINED;
    }

    ap_log_rerror(APLOG_MARK, APLOG_NOERRNO|APLOG_ERR, 0, r,
        "access to %s failed, reason: user %s not allowed access",
        r->uri, user);
    
    note_sspi_auth_failure(r);

    /*
     * We return HTTP_UNAUTHORIZED (401) because the client may wish
     * to authenticate using a different scheme, or a different 
     * username. If this works, they can be granted access. If we 
     * returned HTTP_FORBIDDEN (403) then they don't get a second
     * chance. 
     */
    return HTTP_UNAUTHORIZED;
}

