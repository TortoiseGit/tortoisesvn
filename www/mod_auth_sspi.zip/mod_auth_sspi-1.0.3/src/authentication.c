#include "mod_auth_sspi.h"

static int get_package_max_token_size(PSecPkgInfo pkgInfo, ULONG numPackages, char *package)
{
    ULONG ctr;

    for (ctr = 0; ctr < numPackages; ctr++) {
        if (! strcmp(package, pkgInfo[ctr].Name)) {
            return pkgInfo[ctr].cbMaxToken;
        }
    }

    return 0;
}

static int obtain_credentials(request_rec *r, sspi_connection_rec *scr,
                              sspi_header_rec *hdr, char *domain, char *package)
{
    SECURITY_STATUS ss;
    TimeStamp throwaway;
    sspi_header_rec *auth_id;

#ifdef UNICODE
    #define SEC_WINNT_AUTH_IDENTITY_UNICODE 0x2
    hdr->Flags = SEC_WINNT_AUTH_IDENTITY_UNICODE;
#else
    #define SEC_WINNT_AUTH_IDENTITY_ANSI 0x1
    hdr->Flags = SEC_WINNT_AUTH_IDENTITY_ANSI;
#endif

    if (hdr->authtype == typeBasic) {
        auth_id = hdr;
        if (auth_id->Domain == NULL && domain != NULL) {
            auth_id->Domain = domain;
            auth_id->DomainLength = strlen(domain);
        }
    } else {
        auth_id = NULL;
    }

    if (! (scr->client_credentials.dwLower || scr->client_credentials.dwUpper)) {
        if ((ss = sspiModuleInfo.functable->AcquireCredentialsHandle(
                                        NULL,
                                        package,
                                        SECPKG_CRED_OUTBOUND,
                                        NULL, auth_id, NULL, NULL,
                                        &scr->client_credentials,
                                        &throwaway)
                                        ) != SEC_E_OK) {
            if (ss == SEC_E_SECPKG_NOT_FOUND) {
                ap_log_rerror(APLOG_MARK, APLOG_ERR, APR_FROM_OS_ERROR(GetLastError()), r,
                    "access to %s failed, reason: unable to acquire credentials "
                    "handle", r->uri, package);
            }
            return HTTP_INTERNAL_SERVER_ERROR;
        }
    }

    if (! (scr->server_credentials.dwLower || scr->server_credentials.dwUpper)) {
        if ((ss = sspiModuleInfo.functable->AcquireCredentialsHandle(
                                        NULL,
                                        package,
                                        SECPKG_CRED_INBOUND,
                                        NULL, NULL, NULL, NULL,
                                        &scr->server_credentials,
                                        &throwaway)
                                        ) != SEC_E_OK) {
            return HTTP_INTERNAL_SERVER_ERROR;
        }
    }

    scr->have_credentials = TRUE;

    return OK;
}

apr_status_t cleanup_sspi_connection(void *param)
{
    sspi_connection_rec *scr = (sspi_connection_rec *)param;

    if (scr != NULL) {
        if (scr->client_credentials.dwLower || scr->client_credentials.dwUpper) {
            sspiModuleInfo.functable->FreeCredentialHandle(&scr->client_credentials);
            scr->client_credentials.dwLower = 0;
            scr->client_credentials.dwUpper = 0;
        }

        if (scr->server_credentials.dwLower || scr->server_credentials.dwUpper) {
            sspiModuleInfo.functable->FreeCredentialHandle(&scr->server_credentials);
            scr->server_credentials.dwLower = 0;
            scr->server_credentials.dwUpper = 0;
        }

        if (scr->client_context.dwLower || scr->client_context.dwUpper) {
            sspiModuleInfo.functable->DeleteSecurityContext(&scr->client_context);
            scr->client_context.dwLower = 0;
            scr->client_context.dwUpper = 0;
        }

        if (scr->server_context.dwLower || scr->server_context.dwUpper) {
            sspiModuleInfo.functable->DeleteSecurityContext(&scr->server_context);
            scr->server_context.dwLower = 0;
            scr->server_context.dwUpper = 0;
        }

        scr->have_credentials = FALSE;

        if (scr->usertoken) {
            CloseHandle(scr->usertoken);
            scr->usertoken = NULL;
            /* XXX: Memory for these will only be freed after the connection is closed... possible DOS */
            scr->username = NULL;
            scr->groups = NULL;
        }
    }

    return APR_SUCCESS;
}

static char *get_username_from_context(apr_pool_t *p, 
                                       SecurityFunctionTable *functable, 
                                       CtxtHandle *context)
{
    SecPkgContext_Names names;
    SECURITY_STATUS ss;
    char *retval = NULL;

    if ((ss = functable->QueryContextAttributes(context, 
                                                SECPKG_ATTR_NAMES, 
                                                &names)
        ) == SEC_E_OK) {
        retval = apr_pstrdup(p, names.sUserName);
        functable->FreeContextBuffer(names.sUserName);
    }

    return retval;
}

static void log_sspi_auth_failure(request_rec *r, sspi_header_rec *hdr, apr_status_t errcode, char *reason)
{
    if (hdr->User && hdr->Domain) {
        ap_log_rerror(APLOG_MARK, APLOG_ERR, errcode, r,
            "user %s\\%s: authentication failure for \"%s\"%s", hdr->Domain, hdr->User, r->uri, reason);
    } else if (hdr->User) {
        ap_log_rerror(APLOG_MARK, APLOG_ERR, errcode, r,
            "user %s: authentication failure for \"%s\"%s", hdr->User, r->uri, reason);
    } else {
        ap_log_rerror(APLOG_MARK, APLOG_ERR, errcode, r,
            "authentication failure for \"%s\": user unknown%s", r->uri, reason);
    }
}

static void log_sspi_logon_denied(request_rec *r, sspi_header_rec *hdr, apr_status_t errcode)
{
    log_sspi_auth_failure(r, hdr, errcode, "");
}

static void log_sspi_invalid_token(request_rec *r, sspi_header_rec *hdr, apr_status_t errcode)
{
    log_sspi_auth_failure(r, hdr, errcode, ", reason: cannot generate context");
}

static SECURITY_STATUS gen_client_context(SecurityFunctionTable *functable, 
                                          CredHandle *credentials, 
                                          CtxtHandle *context, TimeStamp *ctxtexpiry,
                                          BYTE *in, DWORD *inlen, BYTE *out, DWORD *outlen,
                                          LPSTR package)
{
    SecBuffer inbuf, outbuf;
    SecBufferDesc inbufdesc, outbufdesc;
    SECURITY_STATUS ss;
    ULONG ContextAttributes;
    BOOL havecontext = (context->dwLower || context->dwUpper);

    outbuf.cbBuffer = *outlen;
    outbuf.BufferType = SECBUFFER_TOKEN;
    outbuf.pvBuffer = out;
    outbufdesc.ulVersion = SECBUFFER_VERSION;
    outbufdesc.cBuffers = 1;
    outbufdesc.pBuffers = &outbuf;

    if (in) {
        inbuf.cbBuffer = *inlen;
        inbuf.BufferType = SECBUFFER_TOKEN;
        inbuf.pvBuffer = in;
        inbufdesc.ulVersion = SECBUFFER_VERSION;
        inbufdesc.cBuffers = 1;
        inbufdesc.pBuffers = &inbuf;
    }

    ss = functable->InitializeSecurityContext(
                        credentials,
                        havecontext ? context : NULL,
                        package,
                        ISC_REQ_DELEGATE,
                        0,
                        SECURITY_NATIVE_DREP,
                        in ? &inbufdesc : NULL,
                        0,
                        context,
                        &outbufdesc,
                        &ContextAttributes,
                        ctxtexpiry);


    if (ss == SEC_I_COMPLETE_NEEDED || ss == SEC_I_COMPLETE_AND_CONTINUE) {
        functable->CompleteAuthToken(context, &outbufdesc);
    }

    *outlen = outbuf.cbBuffer;

    return ss;
}

static SECURITY_STATUS gen_server_context(SecurityFunctionTable *functable, 
                                          CredHandle *credentials, 
                                          CtxtHandle *context, TimeStamp *ctxtexpiry,
                                          BYTE *in, DWORD *inlen, BYTE *out, DWORD *outlen)
                                          
{
    SecBuffer inbuf, outbuf;
    SecBufferDesc inbufdesc, outbufdesc;
    SECURITY_STATUS ss;
    ULONG ContextAttributes;
    BOOL havecontext = (context->dwLower || context->dwUpper);

    outbuf.cbBuffer = *outlen;
    outbuf.BufferType = SECBUFFER_TOKEN;
    outbuf.pvBuffer = out;
    outbufdesc.ulVersion = SECBUFFER_VERSION;
    outbufdesc.cBuffers = 1;
    outbufdesc.pBuffers = &outbuf;

    inbuf.cbBuffer = *inlen;
    inbuf.BufferType = SECBUFFER_TOKEN;
    inbuf.pvBuffer = in;
    inbufdesc.ulVersion = SECBUFFER_VERSION;
    inbufdesc.cBuffers = 1;
    inbufdesc.pBuffers = &inbuf;

    ss = functable->AcceptSecurityContext(
                          credentials,
                          havecontext ? context : NULL,
                          &inbufdesc,
                          ASC_REQ_DELEGATE,
                          SECURITY_NATIVE_DREP,
                          context,
                          &outbufdesc,
                          &ContextAttributes,
                          ctxtexpiry);

    if (ss == SEC_I_COMPLETE_NEEDED || ss == SEC_I_COMPLETE_AND_CONTINUE) {
        functable->CompleteAuthToken(context, &outbufdesc);
    }

    *outlen = outbuf.cbBuffer;

    return ss;
}

static int check_cleartext_auth(request_rec *r, sspi_connection_rec *scr, 
                                sspi_config_rec *crec, sspi_header_rec *hdr)
{
    DWORD cbOut, cbIn, maxTokenSize;
    BYTE *clientbuf, *serverbuf;
    SECURITY_STATUS ss;
    
    maxTokenSize = get_package_max_token_size(sspiModuleInfo.pkgInfo, sspiModuleInfo.numPackages, crec->sspi_package);
    serverbuf = apr_palloc(r->pool, maxTokenSize);
    clientbuf = NULL;
    cbOut = 0;

    do {
        cbIn = cbOut;
        cbOut = maxTokenSize;
        
        ss = gen_client_context(sspiModuleInfo.functable, &scr->client_credentials, &scr->client_context,
                                &scr->client_ctxtexpiry, clientbuf, &cbIn, serverbuf, &cbOut, 
                                crec->sspi_package);

        if (ss == SEC_E_OK || ss == SEC_I_CONTINUE_NEEDED || ss == SEC_I_COMPLETE_AND_CONTINUE) {
            if (clientbuf == NULL) {
                clientbuf = apr_palloc(r->pool, maxTokenSize);
            }

            cbIn = cbOut;
            cbOut = maxTokenSize;
            
            ss = gen_server_context(sspiModuleInfo.functable, &scr->server_credentials, &scr->server_context,
                                    &scr->server_ctxtexpiry, serverbuf, &cbIn, clientbuf, &cbOut);
        }
    } while (ss == SEC_I_CONTINUE_NEEDED || ss == SEC_I_COMPLETE_AND_CONTINUE);

    switch (ss) {
        case SEC_E_OK:
            return OK;

        case SEC_E_INVALID_HANDLE:
        case SEC_E_INTERNAL_ERROR:
        case SEC_E_NO_AUTHENTICATING_AUTHORITY:
        case SEC_E_INSUFFICIENT_MEMORY:
            ap_log_rerror(APLOG_MARK, APLOG_ERR, APR_FROM_OS_ERROR(GetLastError()), r,
                "access to %s failed, reason: cannot generate context", r->uri);
            return HTTP_INTERNAL_SERVER_ERROR;

        case SEC_E_INVALID_TOKEN:
        case SEC_E_LOGON_DENIED:
        default:
            log_sspi_logon_denied(r, hdr, APR_FROM_OS_ERROR(GetLastError()));
            note_sspi_auth_failure(r);
            cleanup_sspi_connection(scr);
            return HTTP_UNAUTHORIZED;
    }
}

static int set_connection_details(request_rec *r, sspi_connection_rec *scr, const char *auth_type, int omitdomain, const char *usernamecase)
{
    SECURITY_STATUS ss;
    
    if (scr->username == NULL) {
        scr->username = get_username_from_context(r->connection->pool, sspiModuleInfo.functable, 
                                                   &scr->server_context);
    }
    
    if (scr->package == NULL) {
        scr->package = apr_pstrdup(r->connection->pool, auth_type);
    }

    if (scr->username != NULL) {
        if (usernamecase == NULL) {
        }
        else if (!lstrcmpi(usernamecase, "Lower")) {
            strlwr(scr->username);
        }
        else if (!lstrcmpi(usernamecase, "Upper")) {
            strupr(scr->username);
        };
		if (omitdomain) {
			char *s = strchr(scr->username, '\\'); 
			if (s)
				r->user = s+1;
			else
				r->user = scr->username;
		} else {
			r->user = scr->username;
		}
        r->ap_auth_type = scr->package;
    } else {
        return HTTP_INTERNAL_SERVER_ERROR;
    }

    if (scr->usertoken == NULL) {
        if ((ss = sspiModuleInfo.functable->ImpersonateSecurityContext(&scr->server_context)) != SEC_E_OK) {
            return HTTP_INTERNAL_SERVER_ERROR;
        }

        if (!OpenThreadToken(GetCurrentThread(), TOKEN_QUERY_SOURCE | TOKEN_READ, TRUE, &scr->usertoken)) {
            sspiModuleInfo.functable->RevertSecurityContext(&scr->server_context);
            return HTTP_INTERNAL_SERVER_ERROR;
        }

        if ((ss = sspiModuleInfo.functable->RevertSecurityContext(&scr->server_context)) != SEC_E_OK) {
            return HTTP_INTERNAL_SERVER_ERROR;
        }
    }

    return OK;
}

static int accept_security_context(request_rec *r, sspi_connection_rec *scr,
                                   sspi_header_rec *hdr, sspi_config_rec *crec)
{
    SECURITY_STATUS ss;
    sspi_header_rec hdrout;

    hdrout.PasswordLength = get_package_max_token_size(sspiModuleInfo.pkgInfo, sspiModuleInfo.numPackages, crec->sspi_package);
    if (!(hdrout.Password = apr_palloc(r->pool, hdrout.PasswordLength))) {
        return HTTP_INTERNAL_SERVER_ERROR;
    }

    ss = gen_server_context(sspiModuleInfo.functable, &scr->server_credentials, &scr->server_context, 
                            &scr->server_ctxtexpiry, hdr->Password, 
                            &hdr->PasswordLength, hdrout.Password, 
                            &hdrout.PasswordLength);
    
    switch (ss) {
        case SEC_E_OK:
            return OK;

        case SEC_I_COMPLETE_NEEDED:
        case SEC_I_CONTINUE_NEEDED:
        case SEC_I_COMPLETE_AND_CONTINUE: /* already completed if 'complete and continue' */
            note_sspi_auth_challenge(r, crec->sspi_package,
                                     uuencode_binary(r->pool, hdrout.Password, hdrout.PasswordLength));
            return HTTP_UNAUTHORIZED;

        case SEC_E_INVALID_TOKEN:
            log_sspi_invalid_token(r, hdr, APR_FROM_OS_ERROR(GetLastError()));
            note_sspi_auth_failure(r);
            cleanup_sspi_connection(scr);
            return HTTP_UNAUTHORIZED;

        case SEC_E_LOGON_DENIED:
            log_sspi_logon_denied(r, hdr, APR_FROM_OS_ERROR(GetLastError()));
            note_sspi_auth_failure(r);
            cleanup_sspi_connection(scr);
            return HTTP_UNAUTHORIZED;

        case SEC_E_INVALID_HANDLE:
        case SEC_E_INTERNAL_ERROR:
        case SEC_E_NO_AUTHENTICATING_AUTHORITY:
        case SEC_E_INSUFFICIENT_MEMORY:
            ap_log_rerror(APLOG_MARK, APLOG_ERR, APR_FROM_OS_ERROR(GetLastError()), r,
                "access to %s failed, reason: cannot generate server context", r->uri);
            return HTTP_INTERNAL_SERVER_ERROR;
    }

    return HTTP_INTERNAL_SERVER_ERROR;
}

int authenticate_sspi_user(request_rec *r)
{
    sspi_config_rec *crec = get_sspi_config_rec(r);
    sspi_connection_rec *scr;
    sspi_header_rec hdr = {0,};
    int res;

#ifdef _DEBUG
    if (sspiModuleInfo.currentlyDebugging == FALSE) {
        sspiModuleInfo.currentlyDebugging = TRUE;
        DebugBreak();
    }
#endif /* def _DEBUG */
            
    if (!crec->sspi_on) {
        return DECLINED;
    }

    if (sspiModuleInfo.supportsSSPI == FALSE) {
        if (crec->sspi_authoritative) {
            ap_log_rerror(APLOG_MARK, APLOG_NOERRNO|APLOG_ERR, 0, r,
                "access to %s failed, reason: SSPI support is not available",
                r->uri);
            return HTTP_INTERNAL_SERVER_ERROR;
        } else {
            return DECLINED;
        }
    }

    if (crec->sspi_package == NULL) {
        crec->sspi_package = sspiModuleInfo.defaultPackage;
    }

    apr_pool_userdata_get((void**)&scr, sspiModuleInfo.userDataKeyString, r->connection->pool);
    
    if (scr == NULL) {
        scr = apr_pcalloc(r->connection->pool, sizeof(sspi_connection_rec));
        scr->pool = r->connection->pool;
        apr_pool_userdata_set((void*)scr, sspiModuleInfo.userDataKeyString, cleanup_sspi_connection, scr->pool);
    }

    if (scr->username == NULL) {
        if (res = get_sspi_header(r, &hdr, crec)) {
            return res;
        }

        if ((! scr->have_credentials) && 
            (res = obtain_credentials(r, scr, &hdr, crec->sspi_domain, crec->sspi_package))) {
            return res;
        }

        if (hdr.authtype == typeSSPI) {
            if (res = accept_security_context(r, scr, &hdr, crec)) {
                return res;
            }
        } else if (hdr.authtype == typeBasic) {
            if (res = check_cleartext_auth(r, scr, crec, &hdr)) {
                return res;
            }
        }

        /* we should stick with per-request auth - per connection can cause 
         * problems with POSTing and would be difficult to code such that different
         * configs were allowed on the same connection (eg. CGI that referred to 
         * images in another directory. */
        apr_pool_cleanup_kill(r->connection->pool, scr, cleanup_sspi_connection);
        apr_pool_cleanup_register(r->pool, scr, cleanup_sspi_connection, apr_pool_cleanup_null);
    }

    if (res = set_connection_details(r, scr, hdr.authtype == typeSSPI ? crec->sspi_package : "Basic", crec->sspi_omitdomain, crec->sspi_usernamecase)) {
        return res;
    }

    return OK;
}

